/**
 * Punto.java
 */
package Dominio;

/**
 *
 * @author Alejandro Galindo, Francisco Felix, Cesar Acactitla
 */
public class Punto extends Forma{
    public Punto(int width, int height, int x, int y) {
        super(width, height, x, y);
    }  
}